package com.jabirdev.photoku.app

object AppConstants {

    const val PREF_APP = "story_app"
    const val PREF_THEME = "theme"

    const val MENU_ABOUT_TYPE_ACCOUNT = 1
    const val MENU_ABOUT_TYPE_ITEM = 0

}